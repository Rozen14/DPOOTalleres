package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

public class ProductoMenuTest {
    
    private ProductoMenu producto1;

    @BeforeEach
    public void setup(){
        producto1 = new ProductoMenu("Hamburguesa", 10000);
    }

    @AfterEach
    public void tearDown(){
        producto1 = null;
    }

    @Test
    public void testGetNombre(){
        assertEquals("Hamburguesa", producto1.getNombre(), "El nombre del producto no es el esperado.");
    }

    @Test
    public void testGetPrecio(){
        assertEquals(10000, producto1.getPrecio(), "El precio del producto no es el esperado.");
    }

    @Test 
    public void testGenerarTextoFactura(){
        assertEquals("Hamburguesa\n            10000\n", producto1.generarTextoFactura(), "El texto de la factura no es el esperado.");
    }

}
