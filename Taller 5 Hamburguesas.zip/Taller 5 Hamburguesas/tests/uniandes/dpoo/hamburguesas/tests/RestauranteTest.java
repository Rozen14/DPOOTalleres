package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Restaurante;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.excepciones.YaHayUnPedidoEnCursoException;
import uniandes.dpoo.hamburguesas.mundo.Combo;

public class RestauranteTest {
    private Restaurante restaurante;
    private ArrayList<ProductoMenu> menuBase;
    private ArrayList<Ingrediente> ingredientes;
    private ArrayList<Pedido> pedidos;
    private ArrayList<Combo> menuCombos;

    @BeforeEach
    public void setup(){
        restaurante = new Restaurante();
        pedidos = new ArrayList<Pedido>();
        pedidos.add(new Pedido("Juan", "Calle 123"));
        pedidos.add(new Pedido("Pedro", "Calle 456"));
        menuBase = new ArrayList<ProductoMenu>();
        menuBase.add(new ProductoMenu("Hamburguesa Sencilla", 10000));
        menuBase.add(new ProductoMenu("Papas Fritas", 3500));
        menuBase.add(new ProductoMenu("Coca Cola", 4000));
        menuCombos = new ArrayList<Combo>();
        menuCombos.add(new Combo("Hamburguesa Con Bebida", 0.9, menuBase));
        menuCombos.add(new Combo("Hamburguesa Con Papas", 0.85, menuBase));
        ingredientes = new ArrayList<Ingrediente>();
        ingredientes.add(new Ingrediente("Aguacate", 2000));
        ingredientes.add(new Ingrediente("Elote", 1500));

    }

    @AfterEach
    public void tearDown(){
        restaurante = null;
        pedidos = null;
        menuBase = null;
        menuCombos = null;
        ingredientes = null;
    }

    @Test
    public void testIniciaPedido() throws YaHayUnPedidoEnCursoException{
        restaurante.iniciarPedido("Juan", "Calle 123");
        assertNotNull(restaurante.getPedidoEnCurso());
    }

    @Test
    public void testIniciaPedidoConPedidoEnCurso() throws YaHayUnPedidoEnCursoException{
        restaurante.iniciarPedido("Juan", "Calle 123");
        assertThrows(YaHayUnPedidoEnCursoException.class, () -> restaurante.iniciarPedido("Juan", "Calle 123"));
    }

    @Test
    public void testGetPedidoEnCurso() throws YaHayUnPedidoEnCursoException{
        restaurante.iniciarPedido("Juan", "Calle 123");
        assertNotNull(restaurante.getPedidoEnCurso());
    }

    @Test 
    public void testGetPedidos(){
        assertNotNull(pedidos);
    }

    @Test
    public void testGetMenuBase(){
        assertNotNull(menuBase);
    }

    @Test
    public void testGetMenuCombos(){
        assertNotNull(menuCombos);
    }

    @Test
    public void testGetIngredientes(){
        assertNotNull(ingredientes);
    }

    @Test
    void testCargaExitosaDeInformacion() throws Exception {
        File archivoIngredientes = new File("data\\ingredientes.txt");
        File archivoMenu = new File("data\\menu.txt");
        File archivoCombos = new File("data\\combos.txt");

        restaurante.cargarInformacionRestaurante(archivoIngredientes, archivoMenu, archivoCombos);

        assertFalse(restaurante.getIngredientes().isEmpty());
        assertFalse(restaurante.getMenuBase().isEmpty());
        assertFalse(restaurante.getMenuCombos().isEmpty());
    }

    
}
