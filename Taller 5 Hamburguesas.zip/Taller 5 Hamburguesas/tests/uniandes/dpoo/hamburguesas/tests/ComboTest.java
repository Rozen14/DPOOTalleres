package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Combo;

public class ComboTest {
    
    private Combo combo;
    private ProductoMenu productoBase;
    private ProductoMenu productoBase2;
    private ArrayList<ProductoMenu> items;

    @BeforeEach
    public void setup(){
        productoBase = new ProductoMenu("Hamburguesa Sencilla", 10000);
        productoBase2 = new ProductoMenu("Coca Cola", 4000);
        items = new ArrayList<ProductoMenu>();
        items.add(productoBase);
        items.add(productoBase2);
        combo = new Combo("Hamburguesa Con Bebida", 0.85, items);
    }

    @AfterEach
    public void tearDown(){
        combo = null;
        productoBase = null;
        productoBase2 = null;
        items = null;
    }

    @Test
    public void testGetNombre(){
        assertEquals("Hamburguesa Con Bebida", combo.getNombre(), "El nombre del combo no es el esperado.");
    }

    @Test
    public void testGetPrecio(){
        assertEquals(11900, combo.getPrecio(), "El precio del combo no es el esperado.");
    }

    @Test
    public void testGenerarTextoFactura(){
        assertEquals("Combo Hamburguesa Con Bebida\n Descuento: 0.85\n            11900\n", combo.generarTextoFactura(), "El texto de la factura no es el esperado.");
    }

}
