package uniandes.dpoo.hamburguesas.tests;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Producto;
import uniandes.dpoo.hamburguesas.mundo.Pedido;

public class PedidoTest {
    private Pedido pedido;
    private int idPedido;
    private ArrayList<Producto> productos;

    @BeforeEach
    public void setup(){
        pedido = new Pedido("Juan", "Calle 123");
        productos = new ArrayList<Producto>();
        productos.add(new ProductoMenu("Hamburguesa Sencilla", 10000));
        productos.add(new ProductoMenu("Coca Cola", 4000));
        idPedido = pedido.getIdPedido();
    }

    @AfterEach
    public void tearDown(){
        pedido = null;
        productos = null;
    }

    @Test
    public void testGetIdPedido(){
        assertEquals(idPedido, pedido.getIdPedido(), "El id del pedido no es el esperado.");
    }

    @Test
    public void testGetNombreCliente(){
        assertEquals("Juan", pedido.getNombreCliente(), "El nombre del cliente no es el esperado.");
    }

    @Test
    public void testGetPrecioTotalPedido(){
        for(Producto producto : productos){
            pedido.agregarProducto(producto);
        }
        assertEquals(16660, pedido.getPrecioTotalPedido(), "El precio total del pedido no es el esperado.");
    }

    @Test
    public void testGenerarTextoFactura(){
        for(Producto producto : productos){
            pedido.agregarProducto(producto);
        }
        assertEquals("Cliente: Juan\nDirección: Calle 123\n----------------\nHamburguesa Sencilla\n            10000\nCoca Cola\n            4000\n----------------\nPrecio Neto:  14000\nIVA:          2660\nPrecio Total: 16660\n", pedido.generarTextoFactura(), "El texto de la factura no es el esperado.");
    }
        
}
