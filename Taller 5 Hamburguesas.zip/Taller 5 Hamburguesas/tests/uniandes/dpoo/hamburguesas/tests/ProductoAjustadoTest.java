package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;
import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

public class ProductoAjustadoTest {
    
    private ProductoAjustado producto1;
    private ProductoMenu productoBase1;
    private Ingrediente ingredienteAg;
    private Ingrediente ingredienteEl;


    @BeforeEach
    public void setup(){
        productoBase1 = new ProductoMenu("Hamburguesa Sencilla", 10000);
        producto1 = new ProductoAjustado(productoBase1);         
        ingredienteAg = new Ingrediente("Aguacate", 2000);
        ingredienteEl = new Ingrediente("Elote", 1500);
    }

    @AfterEach
    public void tearDown(){
        producto1 = null;
        productoBase1 = null;
        ingredienteAg = null;
        ingredienteEl = null;
    }

    @Test
    public void testGetNombre(){
        assertEquals("Hamburguesa Sencilla", producto1.getNombre(), "El nombre del producto no es el esperado.");
    }

    @Test
    public void testGetPrecio(){
        producto1.agregarIngrediente(ingredienteAg);
        assertEquals(12000, producto1.getPrecio(), "El precio del producto no es el esperado.");
    }

    @Test
    public void testGenerarTextoFactura(){
        producto1.agregarIngrediente(ingredienteAg);
        producto1.eliminarIngrediente(ingredienteEl);
        assertEquals("Hamburguesa Sencilla\n            10000\nAguacate\n            2000\nElote\n            -1500\n", producto1.generarTextoFactura(), "El texto de la factura no es el esperado.");
    }

}
